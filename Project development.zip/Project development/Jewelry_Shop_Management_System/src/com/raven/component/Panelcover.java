package com.raven.component;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import net.miginfocom.swing.MigLayout;
import javax.swing.border.Border;

public class Panelcover extends javax.swing.JPanel {
    
    private final DecimalFormat df=new DecimalFormat("##0.###");
    private ActionListener event;
    private MigLayout layout;
    private JLabel label;
    private JLabel title;
    private JLabel description;
    private JButton btn;
    private boolean isLogin;
    
    
    
    public Panelcover() {
        initComponents();
        setOpaque(false);
        layout=new MigLayout("wrap","push[center]push","push[]25[]10[]10[]25[]push");
        setLayout(layout);
        init();
    }
    
    private void init(){      
        title=new JLabel("Italy Silver Choice");
        title.setFont(new Font("Monotype Corsiva", 1, 37));
        title.setForeground(new Color(245,245,245));
        add(title);
        
        description=new JLabel("Where Elegance Meets Brilliance");
        description.setFont(new Font("Monotype Corsiva", 1, 16));
        description.setForeground(new Color(245,245,245));
        add(description);
        
        JButton btn=new JButton();
        Border outlineBorder = BorderFactory.createLineBorder(new Color(255,255,255), 1);
        btn.setBorder(outlineBorder);
        btn.setText("Click me");
        btn.setFont(new Font("TimesNewRoman", 1, 13));
        btn.setBackground(new Color(252, 186, 3));
        btn.setForeground(new Color(255,255,255));
        
        btn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                event.actionPerformed(e);
            }
        });
        add(btn,"w 60%, h 40");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/logo1.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(268, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 155, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
    @Override
    protected void paintComponent(Graphics grphcs){
        Graphics2D g2=(Graphics2D)grphcs;
        GradientPaint gra=new GradientPaint(0,0,new Color(4, 33, 68),0,getHeight(),new Color(12,67,133));
        g2.setPaint(gra);
        g2.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(grphcs);
    }
      public void addEvent(ActionListener event){
        this.event=event;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
