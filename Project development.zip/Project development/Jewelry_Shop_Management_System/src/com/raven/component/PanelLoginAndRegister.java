package com.raven.component;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.TextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import net.miginfocom.swing.MigLayout;


public class PanelLoginAndRegister extends javax.swing.JLayeredPane {
    
    public PanelLoginAndRegister() {
        initComponents();
        initRegister();
        initLogin();
        Login.setVisible(false);
        Register.setVisible(true);
    }
    
    private void initRegister(){
        Register.setLayout(new MigLayout("wrap","push[center]push","push[]25[]10[]10[]25[]push"));
        JLabel label=new JLabel("Create Account");
        label.setFont(new Font("TimesNewRoman", 1, 30));
        label.setForeground(new Color(16, 69, 133));
        Register.add(label);
        
        TextField txtuser=new TextField();
        //txtuser.setText("Name");
        Register.add(txtuser,"w 60%");
        
        TextField txtemail=new TextField();
        //txtemail.setText("Email");
        Register.add(txtemail,"w 60%");
        
        JPasswordField pwd=new JPasswordField();
        //pwd.setText("Password");
        Register.add(pwd,"w 60%");
        
        JButton cmd=new JButton("REGISTER");
        cmd.setBackground(new Color(16, 69, 133));
        cmd.setForeground(new Color(250,250,250));      
        Register.add(cmd,"w 40%, h 40");
        
    }
    
    private void initLogin(){
        Login.setLayout(new MigLayout("wrap","push[center]push","push[]25[]10[]10[]25[]push"));
        JLabel label=new JLabel("SIGN IN");
        label.setFont(new Font("TimesNewRoman", 1, 30));
        label.setForeground(new Color(16, 69, 133));
        Login.add(label);
        
        TextField txtuser=new TextField();
        //txtemail.setText("Email");
        Login.add(txtuser,"w 60%");
        
        JPasswordField pwd=new JPasswordField();
        //pwd.setText("Password");
        Login.add(pwd,"w 60%");
        
        JButton fbtn=new JButton("Forgot Password");
        fbtn.setForeground(new Color(100,100,100));
        fbtn.setFont(new Font("TimesNewRoman", 1, 12));
        fbtn.setContentAreaFilled(false);
        fbtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Login.add(fbtn);
        
        JButton cmd=new JButton("SIGN IN");
        cmd.setBackground(new Color(16, 69, 133));
        cmd.setForeground(new Color(250,250,250));
        Login.add(cmd,"w 40%, h 40");
    }
    
    public void showRegister(boolean show){
        if(show){
            Register.setVisible(true);
            Login.setVisible(false);
        }else{
            Register.setVisible(false);
            Login.setVisible(true);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Register = new javax.swing.JPanel();
        Login = new javax.swing.JPanel();

        setLayout(new java.awt.CardLayout());

        Register.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout RegisterLayout = new javax.swing.GroupLayout(Register);
        Register.setLayout(RegisterLayout);
        RegisterLayout.setHorizontalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        RegisterLayout.setVerticalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(Register, "card2");

        Login.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout LoginLayout = new javax.swing.GroupLayout(Login);
        Login.setLayout(LoginLayout);
        LoginLayout.setHorizontalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        LoginLayout.setVerticalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(Login, "card3");
    }// </editor-fold>//GEN-END:initComponents
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Login;
    private javax.swing.JPanel Register;
    // End of variables declaration//GEN-END:variables
}
