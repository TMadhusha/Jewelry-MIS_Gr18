import axios from "axios"

const RegApi=(Inputs)=>
{
    let Data={
        displayName:Inputs.userName,
        password:Inputs.password
    }

    axios.post
}