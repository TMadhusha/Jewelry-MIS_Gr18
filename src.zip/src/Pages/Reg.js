
import { useState } from 'react'
import './Reg.css'

export default function Reg(){

    const initialStateErrors=
    ({
        userName:{required:false},
        password:{required:false},
      });

    const [Errors,setErrors] = useState(initialStateErrors);

    const [Loading,setLoading]=useState(false); //loding spinner
  const handleSubmit= (event)=>
  {
    event.preventDefault();

    let Er=initialStateErrors;// for check empty
    let hasError=false;
    if (Inputs.userName==""|| null) 
    {
        Er.userName.required=true;
        hasError=true;
    }
    if (Inputs.password==""|| null) 
    {
        Er.password.required=true;
        hasError=true;
    }
    if (hasError!=true) 
    {
        setLoading(true);
     //sending API request   
    }
    setErrors(Er);
  };
 
 const[Inputs,setInputs]= useState
  ({
    userName:"",
    password:""

  });
  const handleInputs=(event)=>
  {
    setInputs({...Inputs,[event.target.name]:event.target.value})
  };

    return (
                <div className="wrapper">
                <div className="logo">
                    <img src="ISC.png" alt=""/>
                </div>
                <div className="text-center mt-4 name">
                    Italy Silver Choice
                </div>
        <form onSubmit={handleSubmit} className="p-3 mt-3">

            <div>
                {Errors.userName.required==true?(
                <span className="Erro" >
                        Username is required.
                </span>):null
                }

                    <div className="form-field d-flex align-items-center">
                        <span className="far fa-user"></span>
                        <input type="text" onChange={handleInputs} name="userName" id="userName" placeholder="Username"/>
                     
                    </div>
            </div>   
            <div>      
                    {Errors.password.required==true?
                    (
                    <span className="Erro" >
                        Password is required.
                    </span>
                    ):null
                    }
                    <div className="form-field d-flex align-items-center">
                        <span className="fas fa-key"></span>
                        <input type="password" minLength="8" onChange={handleInputs} name="password" id="pwd" placeholder="Password"/>
                    </div>
            </div>
            {Loading==true?
            (<div className=" d-flex align-items-center">
                    <div className='loader'></div>
            </div>):null
            }
            <br />
        
                    {/* <button disabled className="btn mt-3">Login</button> */}
                    <input type="submit" disabled={Loading} className="btn mt-3" id="Login" />
        </form>
        <div  className="text-center fs-6">
            <a href="#">Forget password?</a> or <a href="#">Sign up</a>
        </div>
        
    </div>
    )
}