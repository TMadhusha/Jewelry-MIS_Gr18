import Reg from "./Pages/Reg";

function App() {
  return (
    <div className="App">
        <Reg/>
    </div>
  );
}

export default App;
